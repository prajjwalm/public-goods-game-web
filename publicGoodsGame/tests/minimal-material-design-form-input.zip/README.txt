A Pen created at CodePen.io. You can find this one at http://codepen.io/koenigsegg1/pen/adbzLQ.

 Super easy and fully scalable Material Design form input. Change one variable to change the size of everything.