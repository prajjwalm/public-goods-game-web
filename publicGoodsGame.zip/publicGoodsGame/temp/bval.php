<?php
	echo "af";
	echo var_dump(boolval(floatval("0.0")));
?>