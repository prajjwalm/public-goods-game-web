<?php
	echo var_dump(floatval("100.002"));
?>