<?php echo ("4" == 4);
?>