<?php
	//
	// Contains only require_once paths
	// User direct access isn't disabled
	// No client side script/page refers to this,
	// and executing just this will do nothing
	// Will be removed later anyway, kept here for
	// easy transition to linux
	//
	require ("D:/Work/Projects/publicGoodsGame/PGG/src/botvars.php");
	require ("D:/Work/Projects/publicGoodsGame/PGG/src/cxnvars.php");
	require ("D:/Work/Projects/publicGoodsGame/PGG/src/uuid.php");
	// require_once ("D:/Work/Projects/publicGoodsGame/PGG/src/tblvars.php");
	
?>