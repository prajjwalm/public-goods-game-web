<?php
	session_start();
	
	echo var_dump($_SESSION);
	exit();
?>