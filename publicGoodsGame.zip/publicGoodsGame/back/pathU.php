<?php
	require ("/home/prajjwalm/PGG/src/botvars.php");
	require ("/home/prajjwalm/PGG/src/cxnvars.php");
	require ("/home/prajjwalm/PGG/src/uuid.php");
	// require_once ("/home/prajjwalm/PGG/src/tblvars.php");
	
?>